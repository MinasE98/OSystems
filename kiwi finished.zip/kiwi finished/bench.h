#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>
#include <pthread.h>
#define KSIZE (16)
#define VSIZE (1000)

#define LINE "+-----------------------------+----------------+------------------------------+-------------------+\n"
#define LINE1 "---------------------------------------------------------------------------------------------------\n"
pthread_mutex_t calculate_write_time;
pthread_mutex_t calculate_read_time;
double write_time;
double read_time;
long long get_ustime_sec(void);
void _random_key(char *key,int length);

struct input_data{
	long int c;
	int r;
};
