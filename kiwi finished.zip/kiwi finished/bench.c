#include "bench.h"

void *write_test_func(void *arg){
	struct input_data *d=(struct input_data*)arg;
	_write_test(d->c,d->r);
	return 0;
}
void *read_test_func(void *arg){
	struct input_data *d=(struct input_data*)arg;
	_read_test(d->c,d->r);
	return 0;
}


void _random_key(char *key,int length) {
	int i;
	char salt[36]= "abcdefghijklmnopqrstuvwxyz0123456789";

	for (i = 0; i < length; i++)
		key[i] = salt[rand() % 36];
}

void _print_header(int count)
{
	double index_size = (double)((double)(KSIZE + 8 + 1) * count) / 1048576.0;
	double data_size = (double)((double)(VSIZE + 4) * count) / 1048576.0;

	printf("Keys:\t\t%d bytes each\n", 
			KSIZE);
	printf("Values: \t%d bytes each\n", 
			VSIZE);
	printf("Entries:\t%d\n", 
			count);
	printf("IndexSize:\t%.1f MB (estimated)\n",
			index_size);
	printf("DataSize:\t%.1f MB (estimated)\n",
			data_size);

	printf(LINE1);
}

void _print_environment()
{
	time_t now = time(NULL);

	printf("Date:\t\t%s", 
			(char*)ctime(&now));

	int num_cpus = 0;
	char cpu_type[256] = {0};
	char cache_size[256] = {0};

	FILE* cpuinfo = fopen("/proc/cpuinfo", "r");
	if (cpuinfo) {
		char line[1024] = {0};
		while (fgets(line, sizeof(line), cpuinfo) != NULL) {
			const char* sep = strchr(line, ':');
			if (sep == NULL || strlen(sep) < 10)
				continue;

			char key[1024] = {0};
			char val[1024] = {0};
			strncpy(key, line, sep-1-line);
			strncpy(val, sep+1, strlen(sep)-1);
			if (strcmp("model name", key) == 0) {
				num_cpus++;
				strcpy(cpu_type, val);
			}
			else if (strcmp("cache size", key) == 0)
				strncpy(cache_size, val + 1, strlen(val) - 1);	
		}

		fclose(cpuinfo);
		printf("CPU:\t\t%d * %s", 
				num_cpus, 
				cpu_type);

		printf("CPUCache:\t%s\n", 
				cache_size);
	}
}

int main(int argc,char** argv)
{
	long int thread_count=atoi(argv[3]);
	long int count_values=atoi(argv[2]);
	srand(time(NULL));
	pthread_t *id;
	pthread_t *writers_id,*readers_id;/*check if we need malloc*/
	/*writers_id = malloc(sizeof(pthread_t)*thread_count);
    	readers_id= malloc(sizeof(pthread_t)*thread_count);*/
	
	id = malloc(sizeof(pthread_t)*thread_count);
	pthread_mutex_init(&calculate_write_time,NULL);
	pthread_mutex_init(&calculate_read_time,NULL);
	write_time=0;
	read_time=0;
	if (argc < 4) {
		fprintf(stderr,"Usage: db-bench <write | read> <count><threads>\n");
		exit(1);
	}
	
	if (strcmp(argv[1], "write") == 0) {
		int r = 0;
		
		/*created a struct input_data in the header file bench.h to use as arguments in threads*/
		struct input_data thread_args;
		long int count_values_per_thread=count_values/thread_count;
		_print_header(count_values);
		_print_environment();
		if (argc == 5)
			r = 1;
		open_db();/*calling a function to open the db only one time before creating the writers or readers to avoid being opened and closed from every thread*/
		thread_args.c=count_values_per_thread;
		thread_args.r=r;
		for(int i=0;i<thread_count;i++)
			pthread_create(&id[i],NULL, write_test_func,(void*)&thread_args);
		for(int i=0;i<thread_count;i++)
			pthread_join(id[i],NULL);/*making sure all the threads have finished before the main finishes*/
		close_db();
		/*closing the db after the threads have finished*/
			printf(LINE);
		printf("|Random-Write	(done:%ld): %.6f sec/op; %.1f writes/sec(estimated); cost:%.3f(sec);\n"
		,thread_args.c, (double)(write_time / thread_args.c)
		,(double)( thread_args.c/ write_time)
		,write_time);
	} else if (strcmp(argv[1], "read") == 0) {
		int r = 0;
		/*id = malloc(sizeof(pthread_t)*thread_count);*/
		/*created a struct input_data in the header file bench.h to use as arguments in threads*/
		struct input_data thread_args;
		long int count_values_per_thread=count_values/thread_count;
		_print_header(count_values);
		_print_environment();
		if (argc == 5)
			r = 1;
		open_db();/*calling a function to open the db only one time before creating the writers or readers to avoid being opened and closed from every thread*/
		thread_args.c=count_values_per_thread;
		thread_args.r=r;
		for(int i=0;i<thread_count;i++)
			pthread_create(&id[i],NULL, read_test_func,(void*)&thread_args);
		for(int i=0;i<thread_count;i++)
			pthread_join(id[i],NULL);/*making sure all the threads have finished before the main finishes*/
		close_db();
		printf("|Random-Read	(done:%ld): %.6f sec/op; %.1f reads /sec(estimated); cost:%.3f(sec)\n",
		thread_args.c, (double)(read_time / thread_args.c),
		(double)(thread_args.c / read_time),
		read_time);
	} else if(strcmp(argv[1], "readwrite") == 0){
		int r = 0;
		/*creating arguments for writers*/
		struct input_data thread_args_writers;
		/*creating arguments for readers*/
		struct input_data thread_args_readers;
		double percentage_writers=atoi(argv[4]);
		double percentage_readers=atoi(argv[5]);
		int amount_writers=(int)(thread_count*(percentage_writers/100));
		int amount_readers=(int)(thread_count*(percentage_readers/100));
		int amount_values_writers=(long)(count_values*(percentage_writers/100));
		int amount_values_readers=(long)(count_values*(percentage_readers/100));
		long int count_values_per_thread_writers=amount_values_writers/amount_writers;
		long int count_values_per_thread_readers=amount_values_readers/amount_readers;
		writers_id = malloc(sizeof(pthread_t)*amount_writers);
    		readers_id= malloc(sizeof(pthread_t)*amount_readers);
		/*pthread_t writers_id[amount_writers];
		pthread_t readers_id[amount_readers];*/
		_print_header(count_values);
		_print_environment();
		if (argc == 7)
			r = 1;
		open_db();/*calling a function to open the db only one time before creating the writers or readers to avoid being opened and closed from every thread*/
		thread_args_writers.c=count_values_per_thread_writers;
		thread_args_writers.r=r;
		thread_args_readers.c=count_values_per_thread_readers;
		thread_args_readers.r=r;
		for(int i=0;i<amount_writers;i++)
			pthread_create(&writers_id[i],NULL, write_test_func,(void*)&thread_args_writers);
			/*TODO : ask if the correct way to call _read_test is this(we will see on monday 15/3) */
		for(int i=0;i<amount_readers;i++)
			pthread_create(&readers_id[i],NULL, read_test_func,(void*)&thread_args_readers);
		for(int i=0;i<amount_readers;i++)
			pthread_join(readers_id[i],NULL);/*making sure all the threads have finished before the main finishes*/
		for(int i=0;i<amount_writers;i++)
			pthread_join(writers_id[i],NULL);
			/*finishing all threads before main finishes*/
		close_db();
		/*closing the db after the threads have finished*/
		printf(LINE);
		printf("|Random-Write	(done:%ld): %.6f sec/op; %.1f writes/sec(estimated); cost:%.3f(sec);\n"
		,thread_args_writers.c, (double)(write_time / thread_args_writers.c)
		,(double)(thread_args_writers.c / write_time)
		,write_time);
			printf(LINE);
			printf(LINE);
		printf("|Random-Read	(done:%ld): %.6f sec/op; %.1f reads /sec(estimated); cost:%.3f(sec)\n",
		thread_args_readers.c, (double)(read_time / thread_args_readers.c),
		(double)(thread_args_readers.c / read_time),
		read_time);
	}else {
		fprintf(stderr,"Usage: db-bench <write | read> <count> <random>\n");
		exit(1);
	}

	return 1;
}
